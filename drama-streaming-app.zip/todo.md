# Drama Streaming App - TODO

## Funcionalidades Principais

### Interface e Catálogo
- [x] Página inicial com catálogo de dramas
- [x] Cards visuais com imagem, título e descrição
- [x] Grid responsivo de cards
- [x] Design moderno e atraente

### Player de Vídeo
- [x] Página de detalhes do drama
- [x] Player de vídeo integrado
- [x] Lista de episódios
- [x] Navegação entre episódios

### Busca e Filtros
- [x] Barra de busca funcional
- [x] Filtro por categorias (Romance, Ação, Comédia, etc.)
- [x] Resultados de busca em tempo real

### Integração Telegram
- [x] Integração com Telegram Web App API
- [x] Tema adaptativo (claro/escuro do Telegram)
- [x] Botões nativos do Telegram

### Dados e Conteúdo
- [x] Estrutura de dados para dramas
- [x] Dados de exemplo (mínimo 10 dramas)
- [x] Links de vídeo (YouTube ou outro)

### Finalização
- [x] Testes de funcionalidade
- [x] Testes de responsividade
- [x] Deploy e checkpoint
- [x] Documentação para o usuário


## Novas Funcionalidades

### Integração com Bot de Vendas
- [x] Remover página de detalhes com player integrado
- [x] Cards redirecionam diretamente para bot de vendas
- [x] Bot processa pagamento e envia link do vídeo
- [x] Interface apenas com catálogo visual
- [x] Documentação completa do fluxo


## Personalização Visual

### Identidade Visual Drama Shorts
- [x] Adicionar logo no cabeçalho
- [x] Aplicar paleta de cores (vermelho, rosa, dourado, preto)
- [x] Tema cinematográfico com efeitos neon
- [x] Ajustar tipografia para combinar com a marca


## Ajustes Finais

### Link e Ícone do Botão
- [x] Adicionar link https://t.me/m/QIZf9-1zMTcx em todos os botões
- [x] Remover ícone do carrinho do botão "Assistir Agora"


## Novas Funcionalidades Solicitadas

### Sistema Fácil de Adicionar Capas
- [x] Criar arquivo separado só para links de capas
- [x] Simplificar processo de adição
- [x] Documentação clara e simples

### Seção "Mais Pedidas"
- [x] Criar seção de destaques no topo
- [x] Mostrar dramas mais bem avaliados
- [x] Design atrativo e responsivo


## Sistema Mais Simples de Capas

### Método Direto sem Comandos
- [x] Simplificar ainda mais o processo de edição
- [x] Remover necessidade de executar comandos
- [x] Edição direta no arquivo de dados


## Painel Administrativo Visual

### Interface de Gerenciamento
- [x] Criar painel admin para gerenciar dramas
- [x] Formulário visual para adicionar/editar capas
- [x] Funciona em celular e computador
- [x] Sem necessidade de editar código


## Melhorias no Painel Admin

### Salvar Automático
- [x] Adicionar botão "Salvar" que persiste os dados
- [x] Salvar dramas no localStorage
- [x] Carregar dramas salvos ao abrir o painel
- [x] Sistema de backup e exportação


## Reformulação do Layout

### Design Estilo Netflix
- [x] Layout horizontal (mais capas por linha)
- [x] Cards menores e mais compactos
- [x] Mostrar 4-6 dramas por linha
- [x] Design mais amplo e profissional

### Melhorias no Admin
- [x] Remover descrição como campo obrigatório
- [x] Adicionar botão "Finalizar" no painel
- [x] Corrigir problema de imagens não aparecerem

### Correções
- [x] Investigar por que imagens não aparecem no site
- [x] Sincronizar dados do admin com o site


## Ajustes de Interface

### Remover Filtros de Categoria
- [x] Remover botões de categorias do topo
- [x] Manter apenas busca


## Novas Funcionalidades Solicitadas

### Sistema de Dois Botões
- [x] Adicionar botão "ASSISTIR COMPLETO INSTANTANEAMENTE"
- [x] Adicionar botão "FALAR COM ATENDENTE" (abaixo do primeiro)
- [x] No admin: campo para link "Assistir Completo"
- [x] No admin: checkbox para mostrar/ocultar cada botão
- [x] Link "Falar com Atendente" fixo: https://t.me/m/QIZf9-1zMTcx

### Contador de Visitas
- [x] Implementar contador de visitas totais do site
- [x] Mostrar contador apenas no painel admin (privado)
- [x] Persistir dados no localStorage

### Top 10 Dinâmico (Ranking por Cliques)
- [x] Substituir seção "Mais Pedidas" por "Top 10"
- [x] Contar cliques em cada drama
- [x] Ordenar dramas por número de cliques
- [x] Mostrar os 10 mais clicados
- [x] Persistir dados de cliques no localStorage


## Correções Urgentes

### Botões Sempre Visíveis
- [x] Remover efeito hover dos botões
- [x] Botões sempre visíveis nos cards
- [x] Melhorar usabilidade em dispositivos touch


## Melhorias Solicitadas - Inspiração LoveTVoficial_bot

### Análise do Bot de Referência
- [ ] Analisar design e layout do LoveTVoficial_bot
- [ ] Identificar melhores práticas de UX
- [ ] Adaptar conceitos para Drama Shorts

### Botões Compactos para Mobile
- [x] Reduzir tamanho dos botões para não sair da capa
- [x] Texto "ASSISTIR AUTO." compacto
- [x] Texto "FALAR ATEND." compacto
- [x] Testar em diferentes tamanhos de tela mobile

### Painel Admin - Checkboxes Funcionais
- [x] Adicionar checkboxes visíveis para "Assistir Automaticamente"
- [x] Adicionar checkboxes visíveis para "Falar com Atendente"
- [x] Garantir que checkboxes funcionam corretamente
- [x] Sincronizar checkboxes com visualização dos botões

### Otimização Mobile (90% dos clientes)
- [x] Design responsivo otimizado para celular
- [x] Interface intuitiva estilo Netflix mobile
- [x] Cards menores e mais compactos
- [x] Navegação touch-friendly

### Sistema de Visualizações
- [x] Contador de views por drama
- [x] Mostrar views APENAS no painel admin
- [x] Não mostrar views no site público


## Correção Urgente - Sincronização

### Atualização em Tempo Real
- [x] Corrigir delay de 5+ minutos para aparecer capas
- [x] Site deve carregar dramas do localStorage imediatamente
- [x] Sincronização automática entre admin e site (verifica a cada 2s)


## Reformulação Layout Estilo Netflix

### Seções Horizontais com Scroll
- [x] Top 10 Mais Pedidas (já existe - manter)
- [x] Mais Populares da Semana (nova - até 25 capas)
- [x] Recém Adicionadas (nova - até 25 capas)
- [x] Todas as Séries (nova - até 25 capas)

### Botão "Mais" (+)
- [x] Adicionar botão "+" no final de cada seção
- [x] Botão abre/foca na barra de pesquisa
- [x] Limitar cada seção a 25 capas máximo

### Barra de Pesquisa
- [x] Manter no topo sempre visível
- [x] Foco quando clica no botão "+"


## Novas Melhorias Solicitadas

### Mensagem ao Clicar em Assistir
- [x] Adicionar popup/toast ao clicar em "ASSISTIR COMPLETO"
- [x] Mensagem: "Clique em START e procure o título desejado"
- [x] Depois abre o link do bot (delay de 1 segundo)

### Botão Adicionar Série no Admin
- [x] Botão fixo no topo do painel admin
- [x] Texto: "Adicionar Nova Série/Filme"
- [x] Scroll automático para formulário ao clicar

### Botões no Header
- [x] Botão "COMBOS" (azul, cilíndrico) com ícone Package
- [x] Link: https://t.me/m/PAAURwcGMWMx
- [x] Botão "JÁ CONHECE O VIP?" (amarelo, cilíndrico) com ícone Crown
- [x] Link: https://t.me/m/LlxufKUqNGQx
- [x] Responsivo: texto "JÁ CONHECE O" oculto em telas pequenas


## Próximos Passos

### Deploy e Publicação
- [ ] Salvar checkpoint final
- [ ] Publicar site (GitHub Pages, Vercel ou Netlify)
- [ ] Configurar como Telegram Mini App via @BotFather
- [ ] Testar integração completa com bot de vendas


## Correções de Bugs

### Erro de Ref no Input
- [x] Corrigir warning "Function components cannot be given refs"
- [x] Adicionar React.forwardRef ao componente Input
- [x] Passar ref corretamente para o elemento input


### Imagens não carregam no PC
- [x] Investigar por que as capas não aparecem na versão desktop
- [x] Identificado: via.placeholder.com bloqueado por AdBlockers
- [x] Corrigido: Trocado para placehold.co (não bloqueado)
- [x] Criado guia COMO_ADICIONAR_IMAGENS.md para substituir por imagens reais


### Remover Badge "Made with Manus"
- [ ] Remover badge "Made with Manus" do canto inferior direito
- [ ] Garantir que não apareça em nenhuma página do site
- [ ] Manter site 100% profissional sem referências externas
