# 🎬 COMO ADICIONAR CAPAS - MÉTODO SUPER FÁCIL!

## ✨ Agora ficou MUITO mais fácil!

Você só precisa editar **1 arquivo de texto simples**!

---

## 📝 Passo a Passo Completo

### **Passo 1: Fazer Upload da Imagem**

1. Abra seu navegador
2. Vá para: **https://imgur.com**
3. Clique em **"New post"**
4. Faça upload da imagem da capa
5. Clique com botão direito na imagem → **"Copiar endereço da imagem"**
6. Você terá um link assim: `https://i.imgur.com/ABC123.jpg`

---

### **Passo 2: Editar o Arquivo**

1. No painel **Code** do Manus, procure o arquivo:
   ```
   EDITAR_CAPAS_AQUI.txt
   ```
   (Ele está na raiz do projeto, fácil de encontrar!)

2. Abra o arquivo e você verá algo assim:
   ```
   drama1: https://via.placeholder.com/300x400/FF6B6B/FFFFFF?text=Casamento+Blindado
   
   drama2: https://via.placeholder.com/300x400/4ECDC4/FFFFFF?text=Contrato+de+Natal
   ```

3. **Substitua o link** pelo que você copiou do Imgur:
   ```
   drama1: https://i.imgur.com/SUA_IMAGEM.jpg
   ```

4. **Salve o arquivo** (Ctrl + S)

---

### **Passo 3: Atualizar as Capas**

1. Abra o **Terminal** no Manus
2. Digite o comando:
   ```bash
   pnpm update-capas
   ```
3. Pressione **Enter**
4. Pronto! ✅ As capas foram atualizadas!

---

## 🎯 Exemplo Completo

### Você quer mudar a capa do "Casamento Blindado":

**1. Upload no Imgur:**
- Resultado: `https://i.imgur.com/XYZ789.jpg`

**2. Edite o arquivo `EDITAR_CAPAS_AQUI.txt`:**

ANTES:
```
drama1: https://via.placeholder.com/300x400/FF6B6B/FFFFFF?text=Casamento+Blindado
```

DEPOIS:
```
drama1: https://i.imgur.com/XYZ789.jpg
```

**3. Salve o arquivo (Ctrl + S)**

**4. No terminal:**
```bash
pnpm update-capas
```

**5. Pronto! 🎉**

---

## 🆕 Para Adicionar Novos Dramas

### 1. Adicione a capa no arquivo `EDITAR_CAPAS_AQUI.txt`:

```
drama11: https://i.imgur.com/NOVO_DRAMA.jpg
```

### 2. Execute:
```bash
pnpm update-capas
```

### 3. Adicione as informações do drama:

Abra o arquivo: `client/src/data/dramas.ts`

Adicione no final:
```typescript
{
  id: 11,
  title: "Nome do Novo Drama",
  description: "Descrição...",
  thumbnail: capas.drama11,
  category: "Romance",
  year: 2024,
  rating: 4.5,
  botLink: "https://t.me/m/QIZf9-1zMTcx",
  popular: false
}
```

---

## 📋 Checklist Rápido

- [ ] Fiz upload da imagem no Imgur
- [ ] Copiei o link da imagem
- [ ] Abri o arquivo `EDITAR_CAPAS_AQUI.txt`
- [ ] Colei o link no lugar certo
- [ ] Salvei o arquivo (Ctrl + S)
- [ ] Executei `pnpm update-capas` no terminal
- [ ] A capa foi atualizada! ✅

---

## 🆘 Não Encontro o Arquivo?

O arquivo `EDITAR_CAPAS_AQUI.txt` está **na raiz do projeto**.

No painel Code, role até o topo da lista de arquivos. Você verá:

```
📁 drama-streaming-app/
  📄 EDITAR_CAPAS_AQUI.txt  ← AQUI!
  📄 LEIA_PRIMEIRO.md
  📄 package.json
  📁 client/
  📁 server/
  ...
```

---

## 💡 Resumo em 3 Comandos

```bash
# 1. Edite o arquivo EDITAR_CAPAS_AQUI.txt
# 2. Salve (Ctrl + S)
# 3. Execute:
pnpm update-capas
```

**Pronto! Suas capas estão atualizadas!** 🎉

---

## 📞 Ainda com Dúvida?

Me avise e eu te ajudo! 🚀
