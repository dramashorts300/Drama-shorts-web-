# 🎬 Como Adicionar Imagens Reais dos Dramas

## 📌 Problema Atual

As imagens temporárias (placeholders) funcionam, mas você precisa substituí-las pelas **capas reais** dos seus dramas para o site ficar profissional.

---

## ✅ Método Recomendado: Imgur (Grátis e Rápido)

### Passo 1: Acessar o Imgur
1. Abra o navegador e vá para: **https://imgur.com**
2. **NÃO precisa criar conta** (pode fazer upload anônimo)

### Passo 2: Fazer Upload da Imagem
1. Clique em **"New post"** (botão verde no topo)
2. Arraste a imagem da capa do drama OU clique para selecionar do computador
3. Aguarde o upload terminar

### Passo 3: Copiar o Link Direto
1. Depois do upload, clique com botão direito na imagem
2. Selecione **"Copiar endereço da imagem"** ou **"Copy image address"**
3. O link copiado será algo como: `https://i.imgur.com/ABC1234.jpg`

### Passo 4: Colar no Painel Admin
1. Abra o site e vá para o **Painel Admin** (botão ⚙️ no canto superior direito)
2. Encontre o drama que quer editar
3. No campo **"Link da Capa (Thumbnail)"**, cole o link do Imgur
4. Clique em **"Salvar"** e depois em **"Finalizar"**

---

## 🎨 Dicas para Imagens Perfeitas

### Tamanho Ideal
- **Proporção**: 2:3 (exemplo: 300x450px ou 600x900px)
- **Formato**: JPG ou PNG
- **Peso**: Máximo 2MB para carregar rápido

### Qualidade
- Use imagens de **alta resolução** (mínimo 300x450px)
- Evite imagens pixeladas ou borradas
- Prefira capas oficiais dos dramas

### Onde Encontrar Capas
- Google Imagens: `"nome do drama" poster`
- Sites de dramas e séries
- Redes sociais oficiais dos dramas
- Criar suas próprias capas no Canva

---

## 🔄 Alternativas ao Imgur

### 1. ImgBB (https://imgbb.com)
- Grátis e sem conta
- Processo similar ao Imgur
- Copie o link "Direct link"

### 2. Postimages (https://postimages.org)
- Upload rápido
- Sem necessidade de cadastro
- Use o link "Direct link"

### 3. Google Drive (se você tem conta Google)
1. Faça upload da imagem no Drive
2. Clique com botão direito → "Compartilhar"
3. Altere para "Qualquer pessoa com o link"
4. Copie o ID do link (entre `/d/` e `/view`)
5. Use este formato: `https://drive.google.com/uc?id=SEU_ID_AQUI`

---

## ⚠️ IMPORTANTE: Links que NÃO Funcionam

❌ **NÃO use links que terminam com:**
- `.html` (página web, não imagem)
- Sem extensão de imagem (precisa ter .jpg, .png, .webp, etc.)

❌ **NÃO use links de sites que exigem login:**
- Dropbox sem link público
- OneDrive sem permissão
- Google Photos privado

✅ **Use SEMPRE links diretos da imagem:**
- Que terminam em `.jpg`, `.png`, `.webp`, `.gif`
- Que abrem a imagem diretamente no navegador
- De serviços públicos de hospedagem

---

## 🚀 Exemplo Prático Completo

### Antes (placeholder temporário):
```
https://placehold.co/300x450/1a1a1a/e91e63?text=Casamento+Blindado
```

### Depois (imagem real do Imgur):
```
https://i.imgur.com/Kx7mP9Q.jpg
```

### Como Fazer:
1. Baixe ou tenha a capa do drama "Casamento Blindado"
2. Acesse https://imgur.com
3. Clique em "New post" e faça upload
4. Copie o link direto (ex: `https://i.imgur.com/Kx7mP9Q.jpg`)
5. No Painel Admin, cole no campo "Link da Capa" do drama "Casamento Blindado"
6. Clique em "Salvar" e depois "Finalizar"
7. Pronto! A capa real aparecerá no site

---

## 📱 Testando as Imagens

Depois de adicionar as imagens:

1. **Teste no celular** (90% dos seus usuários)
2. **Teste no PC** com e sem AdBlock
3. **Verifique se carrega rápido** (máximo 2-3 segundos)
4. **Confirme que a proporção está correta** (não distorcida)

---

## 💡 Dica Extra: Adicionar Várias Imagens de Uma Vez

Se você tem muitas capas para adicionar:

1. Faça upload de todas no Imgur de uma vez
2. Copie todos os links em um bloco de notas
3. Vá no Painel Admin e cole um por um
4. Salve tudo de uma vez no final

---

## ❓ Problemas Comuns

### "A imagem não aparece no site"
- Verifique se o link é direto (termina em .jpg, .png, etc.)
- Teste o link abrindo em uma nova aba do navegador
- Confirme que clicou em "Salvar" e "Finalizar" no admin

### "Imagem aparece cortada ou distorcida"
- Use imagens com proporção 2:3 (altura = 1.5x largura)
- Redimensione a imagem antes de fazer upload

### "Imagem demora muito para carregar"
- Reduza o tamanho do arquivo (use TinyPNG.com)
- Comprima a imagem antes do upload

---

## 🎯 Checklist Final

- [ ] Todas as 10 capas substituídas por imagens reais
- [ ] Links testados abrindo em nova aba
- [ ] Imagens com boa qualidade e proporção correta
- [ ] Site testado no celular e PC
- [ ] Carregamento rápido (menos de 3 segundos)

---

**Pronto!** Agora você sabe como adicionar imagens profissionais no seu site Drama Shorts! 🎬✨
