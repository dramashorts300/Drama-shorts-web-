# 🎨 Como Adicionar Capas - SUPER FÁCIL!

## 🚀 Método Simplificado (Recomendado)

Agora ficou **MUITO MAIS FÁCIL** adicionar capas! Você só precisa editar **1 arquivo**.

### Passo 1: Fazer Upload da Imagem

1. Acesse [Imgur.com](https://imgur.com)
2. Clique em "New post"
3. Faça upload da imagem da capa
4. Clique com botão direito na imagem → "Copiar endereço da imagem"
5. Você terá um link como: `https://i.imgur.com/ABC123.jpg`

### Passo 2: Adicionar o Link no Arquivo

Abra o arquivo: `/client/src/data/capas.ts`

```typescript
export const capas = {
  // Cole os links aqui:
  drama1: "https://i.imgur.com/SUA_IMAGEM.jpg", // ← Cole aqui!
  drama2: "https://i.imgur.com/OUTRA_IMAGEM.jpg",
  drama3: "https://i.imgur.com/MAIS_UMA.jpg",
  // ...
};
```

### Passo 3: Pronto! ✅

Salve o arquivo e as capas serão atualizadas automaticamente!

---

## 📋 Dicas Importantes

### Tamanho Ideal das Imagens
- **Proporção:** 3:4 (vertical)
- **Resolução:** 300x400px ou 600x800px
- **Formato:** JPG ou PNG

### Sites para Hospedar Imagens (Grátis)
- ✅ **Imgur** (Recomendado) - https://imgur.com
- ✅ **ImgBB** - https://imgbb.com
- ✅ **Postimages** - https://postimages.org

### Otimizar Imagens
Use estas ferramentas para reduzir o tamanho sem perder qualidade:
- [TinyPNG](https://tinypng.com)
- [Squoosh](https://squoosh.app)

---

## 🎯 Como Adicionar Mais Dramas

### 1. Adicionar Nova Capa

No arquivo `/client/src/data/capas.ts`:

```typescript
export const capas = {
  drama1: "link1.jpg",
  drama2: "link2.jpg",
  // ... dramas existentes
  
  drama11: "https://i.imgur.com/NOVO_DRAMA.jpg", // ← Novo drama!
};
```

### 2. Adicionar Informações do Drama

No arquivo `/client/src/data/dramas.ts`:

```typescript
export const dramas: Drama[] = [
  // ... dramas existentes
  
  {
    id: 11, // ← Próximo ID
    title: "Nome do Novo Drama",
    description: "Descrição interessante...",
    thumbnail: capas.drama11, // ← Usa a capa do arquivo capas.ts
    category: "Romance", // Romance, Ação, Comédia, Drama, Suspense, Aventura
    year: 2024,
    rating: 4.5,
    botLink: "https://t.me/m/QIZf9-1zMTcx",
    popular: false // true = aparece em "Mais Pedidas"
  }
];
```

---

## ⭐ Como Marcar Drama como "Mais Pedido"

Para um drama aparecer na seção **"Mais Pedidas"** no topo:

No arquivo `/client/src/data/dramas.ts`, adicione `popular: true`:

```typescript
{
  id: 1,
  title: "Drama Popular",
  // ... outros campos
  popular: true // ← Adicione esta linha!
}
```

**Dica:** Marque apenas 4-6 dramas como populares para não poluir a seção!

---

## 🔄 Fluxo Completo de Edição

```
1. Upload da imagem no Imgur
   ↓
2. Copiar link da imagem
   ↓
3. Colar em /client/src/data/capas.ts
   ↓
4. Salvar arquivo
   ↓
5. Capas atualizadas automaticamente! ✅
```

---

## 📂 Estrutura de Arquivos

```
client/src/data/
├── capas.ts       ← EDITE AQUI: Links das capas
├── dramas.ts      ← EDITE AQUI: Informações dos dramas
```

**Vantagem:** Separar capas facilita a manutenção!

---

## 🆘 Problemas Comuns

### "A imagem não aparece"

**Solução:**
1. Verifique se o link está correto
2. Teste o link abrindo em uma nova aba
3. Certifique-se de que a imagem é pública

### "Erro ao salvar"

**Solução:**
1. Verifique se não esqueceu vírgulas entre os itens
2. Certifique-se de que o link está entre aspas
3. Exemplo correto:
   ```typescript
   drama1: "link1.jpg",  // ← Vírgula no final
   drama2: "link2.jpg",  // ← Vírgula no final
   ```

---

## 💡 Exemplo Completo

### Arquivo: `/client/src/data/capas.ts`

```typescript
export const capas = {
  drama1: "https://i.imgur.com/ABC123.jpg",
  drama2: "https://i.imgur.com/DEF456.jpg",
  drama3: "https://i.imgur.com/GHI789.jpg",
  // Adicione mais aqui...
};
```

### Arquivo: `/client/src/data/dramas.ts`

```typescript
export const dramas: Drama[] = [
  {
    id: 1,
    title: "Meu Drama Incrível",
    description: "Uma história emocionante...",
    thumbnail: capas.drama1, // ← Usa a capa do arquivo capas.ts
    category: "Romance",
    year: 2024,
    rating: 4.8,
    botLink: "https://t.me/m/QIZf9-1zMTcx",
    popular: true // ← Aparece em "Mais Pedidas"
  },
  // Adicione mais dramas aqui...
];
```

---

## 🎉 Pronto!

Agora você pode adicionar e editar capas de forma **super rápida e fácil**!

Qualquer dúvida, consulte este guia! 🚀✨
