#!/usr/bin/env node

/**
 * Script para atualizar capas automaticamente
 * Lê o arquivo EDITAR_CAPAS_AQUI.txt e atualiza capas.ts
 */

const fs = require('fs');
const path = require('path');

const inputFile = path.join(__dirname, 'EDITAR_CAPAS_AQUI.txt');
const outputFile = path.join(__dirname, 'client/src/data/capas.ts');

console.log('🎬 Atualizando capas dos dramas...\n');

try {
  // Ler arquivo de entrada
  const content = fs.readFileSync(inputFile, 'utf-8');
  
  // Extrair links das capas
  const capas = {};
  const lines = content.split('\n');
  
  lines.forEach(line => {
    const match = line.match(/^(drama\d+):\s*(.+)$/);
    if (match) {
      const [, dramaId, url] = match;
      capas[dramaId] = url.trim();
      console.log(`✅ ${dramaId}: ${url.trim().substring(0, 50)}...`);
    }
  });
  
  // Gerar conteúdo do arquivo capas.ts
  const tsContent = `/**
 * 🎬 ARQUIVO DE CAPAS - Gerado automaticamente
 * 
 * NÃO EDITE ESTE ARQUIVO DIRETAMENTE!
 * Edite o arquivo EDITAR_CAPAS_AQUI.txt na raiz do projeto
 * e execute: pnpm update-capas
 */

export const capas = {
${Object.entries(capas).map(([id, url]) => `  ${id}: "${url}",`).join('\n')}
};
`;
  
  // Salvar arquivo
  fs.writeFileSync(outputFile, tsContent, 'utf-8');
  
  console.log(`\n✨ Capas atualizadas com sucesso!`);
  console.log(`📁 Arquivo gerado: ${outputFile}\n`);
  
} catch (error) {
  console.error('❌ Erro ao atualizar capas:', error.message);
  process.exit(1);
}
