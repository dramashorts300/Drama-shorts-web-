# 🎬 Tutorial SUPER SIMPLES - Como Adicionar Capas

## 📸 Passo 1: Fazer Upload da Imagem

### 1.1 - Acesse o Imgur

- Abra seu navegador

- Vá para: [**https://imgur.com**](https://imgur.com)

### 1.2 - Faça Upload

1. Clique no botão **"New post"** (ou "Novo post")

1. Clique em **"Browse"** ou arraste sua imagem

1. Selecione a imagem da capa do drama

1. Aguarde o upload terminar

### 1.3 - Copie o Link

1. Quando a imagem aparecer, clique com o **botão direito** nela

1. Escolha **"Copiar endereço da imagem"** (ou "Copy image address")

1. O link copiado será algo assim:

---

## 📝 Passo 2: Colar o Link no Arquivo

### 2.1 - Abra o Projeto no Manus

No painel **Code** (Código) do Manus, navegue até:

```
client → src → data → capas.ts
```

### 2.2 - Edite o Arquivo

Você verá algo assim:

```typescript
export const capas = {
  drama1: "https://via.placeholder.com/300x400/FF6B6B/FFFFFF?text=Casamento+Blindado",
  drama2: "https://via.placeholder.com/300x400/4ECDC4/FFFFFF?text=Contrato+de+Natal",
  drama3: "https://via.placeholder.com/300x400/FFE66D/333333?text=Amor+Verdadeiro",
  // ...
};
```

### 2.3 - Substitua o Link

**ANTES:**

```typescript
drama1: "https://via.placeholder.com/300x400/FF6B6B/FFFFFF?text=Casamento+Blindado",
```

**DEPOIS:**

```typescript
drama1: "https://i.imgur.com/SUA_IMAGEM.jpg",
```

**Cole o link que você copiou do Imgur!**

---

## ✅ Passo 3: Salvar

1. Clique em **"Save"** (Salvar) ou pressione **Ctrl + S**

1. Pronto! A capa foi atualizada! 🎉

---

## 🎯 Exemplo Prático Completo

### Situação: Você quer adicionar a capa do drama "Casamento Blindado"

**1. Faça upload da imagem no Imgur:**

- Resultado: `https://i.imgur.com/XYZ789.jpg`

**2. Abra o arquivo ****`capas.ts`**

**3. Encontre a linha do drama1:**

```typescript
drama1: "https://via.placeholder.com/...",
```

**4. Substitua pelo seu link:**

```typescript
drama1: "https://i.imgur.com/XYZ789.jpg",
```

**5. Salve o arquivo (Ctrl + S)**

**6. Pronto! ✅**

---

## 🔄 Para Adicionar MAIS Dramas

### Adicionar Drama 11 (novo)

**1. No arquivo ****`capas.ts`****, adicione uma nova linha:**

```typescript
export const capas = {
  drama1: "link1.jpg",
  drama2: "link2.jpg",
  // ... dramas existentes ...
  drama10: "link10.jpg",
  
  drama11: "https://i.imgur.com/NOVO_DRAMA.jpg", // ← NOVO!
};
```

**2. No arquivo ****`dramas.ts`****, adicione as informações:**

Navegue até: `client → src → data → dramas.ts`

Role até o final do array e adicione:

```typescript
export const dramas: Drama[] = [
  // ... dramas existentes ...
  
  {
    id: 11, // ← Próximo número
    title: "Nome do Novo Drama",
    description: "Descrição do drama...",
    thumbnail: capas.drama11, // ← Usa a capa que você adicionou
    category: "Romance", // Romance, Ação, Comédia, Drama, Suspense, Aventura
    year: 2024,
    rating: 4.5,
    botLink: "https://t.me/m/QIZf9-1zMTcx",
    popular: false // true = aparece em "Mais Pedidas"
  }
];
```

---

## 📋 Checklist Rápido

Ao adicionar uma nova capa:

- [x] Fiz upload da imagem no Imgur

- [x] Copiei o link da imagem

- [ ] Abri o arquivo `capas.ts`

- [ ] Colei o link no lugar certo

- [ ] Salvei o arquivo (Ctrl + S)

- [ ] A capa apareceu no site! ✅

---

## 🆘 Problemas Comuns

### "Não encontro o arquivo capas.ts"

**Caminho completo:**

```
drama-streaming-app
└── client
    └── src
        └── data
            └── capas.ts  ← AQUI!
```

### "A imagem não aparece"

**Verifique:**

1. O link está entre aspas? `"link aqui"`

1. Tem vírgula no final? `"link",`

1. O link funciona? Abra em uma nova aba do navegador

### "Deu erro ao salvar"

**Verifique a sintaxe:**

```typescript
// ✅ CORRETO:
drama1: "link1.jpg",
drama2: "link2.jpg",

// ❌ ERRADO (falta vírgula):
drama1: "link1.jpg"
drama2: "link2.jpg"

// ❌ ERRADO (falta aspas):
drama1: link1.jpg,
```

---

## 💡 Dicas Extras

### Tamanho Ideal da Imagem

- **Largura:** 300-600px

- **Altura:** 400-800px

- **Proporção:** 3:4 (vertical, como pôster de filme)

### Comprimir Imagens

Para imagens mais leves e site mais rápido:

- Acesse: [https://tinypng.com](https://tinypng.com)

- Faça upload da imagem

- Baixe a versão comprimida

- Depois faça upload no Imgur

---

## 🎉 Resumo em 3 Passos

```
1. Upload no Imgur → Copiar link
         ↓
2. Abrir capas.ts → Colar link
         ↓
3. Salvar (Ctrl + S) → Pronto! ✅
```

---

## 📞 Ainda com Dúvida?

Se ainda tiver dificuldade, me avise e eu te ajudo passo a passo! 🚀

**Lembre-se:** É só copiar e colar links! Muito simples! 😊

