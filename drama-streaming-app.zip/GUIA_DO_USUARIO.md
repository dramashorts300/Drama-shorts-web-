# 📺 Guia do Usuário - Drama Streaming App

## 🎯 O Que É Este Site?

Este é um **catálogo visual de dramas e séries** integrado ao Telegram. O site funciona como uma vitrine onde os usuários podem navegar pelos dramas disponíveis e, ao clicar em "Assistir Agora", são redirecionados para um bot de vendas no Telegram.

## 🔄 Como Funciona o Fluxo Completo

### 1. **Usuário Navega no Catálogo**
- O site exibe cards com capas, títulos, descrições e avaliações dos dramas
- Possui busca por nome e filtros por categoria (Romance, Ação, Comédia, etc.)
- Interface responsiva que funciona em celular, tablet e desktop

### 2. **Usuário Clica em "Assistir Agora"**
- Ao clicar no botão, o usuário é redirecionado para o Telegram
- Abre automaticamente o bot de vendas com um parâmetro único do drama

### 3. **Bot de Vendas Processa o Pagamento**
- O bot identifica qual drama o usuário quer assistir
- Processa o pagamento (Telegram Stars, Stripe, PIX, etc.)
- Após confirmação do pagamento, envia o link de acesso

### 4. **Cliente Recebe Acesso ao Grupo/Canal Privado**
- O bot envia um link de convite para um grupo ou canal privado do Telegram
- Nesse grupo/canal estão hospedados os vídeos dos dramas
- Cliente assiste diretamente pelo Telegram

---

## ⚙️ Como Personalizar o Site

### 📝 1. Adicionar Seus Dramas

Edite o arquivo `/client/src/data/dramas.ts`:

```typescript
export const dramas: Drama[] = [
  {
    id: 1,
    title: "Nome do Seu Drama",
    description: "Descrição completa do drama",
    thumbnail: "URL_DA_IMAGEM_DE_CAPA",
    category: "Romance", // Romance, Ação, Comédia, Drama, Suspense, Aventura
    year: 2024,
    rating: 4.8, // De 0 a 5
    botLink: "https://t.me/SeuBotDeVendasBot?start=drama1"
  },
  // Adicione mais dramas aqui...
];
```

**Dicas:**
- Use imagens de alta qualidade (recomendado: 300x400px)
- Mantenha descrições concisas (2-3 linhas)
- O parâmetro `?start=drama1` deve ser único para cada drama

### 🤖 2. Configurar o Bot de Vendas

Cada drama tem um `botLink` único. Exemplo:
```
https://t.me/SeuBotDeVendasBot?start=drama1
```

**No seu bot Python**, você receberá o parâmetro assim:

```python
@bot.message_handler(commands=['start'])
def start(message):
    args = message.text.split()
    if len(args) > 1:
        drama_id = args[1]  # Ex: "drama1"
        # Mostre informações do drama e opções de pagamento
```

### 🎨 3. Personalizar Cores e Estilo

Edite `/client/src/index.css` para mudar as cores:

```css
:root {
  --primary: 220 90% 56%; /* Cor principal (botões) */
  --background: 0 0% 100%; /* Cor de fundo */
  --foreground: 222.2 84% 4.9%; /* Cor do texto */
}
```

### 🏷️ 4. Adicionar Categorias

Edite o array de categorias em `/client/src/data/dramas.ts`:

```typescript
export const categories = [
  "Todos",
  "Romance",
  "Ação",
  "Comédia",
  "Drama",
  "Suspense",
  "Aventura",
  "Terror", // Adicione novas categorias aqui
  "Ficção Científica"
];
```

---

## 🚀 Como Publicar o Site

### Opção 1: GitHub Pages (Gratuito)

1. **Faça upload dos arquivos para o GitHub**
2. **Ative o GitHub Pages:**
   - Vá em Settings → Pages
   - Source: Deploy from a branch
   - Branch: main → / (root)
   - Clique em Save

3. **Sua URL será:**
   ```
   https://seu-usuario.github.io/nome-do-repositorio/
   ```

### Opção 2: Vercel (Gratuito)

1. Acesse [vercel.com](https://vercel.com)
2. Conecte seu repositório do GitHub
3. Deploy automático!

### Opção 3: Netlify (Gratuito)

1. Acesse [netlify.com](https://netlify.com)
2. Arraste a pasta `dist` após build
3. Site publicado!

---

## 🔗 Integrar com Telegram Mini App

### 1. Criar o Mini App no @BotFather

```
/newapp
- Selecione seu bot
- Título: Drama Streaming
- Nome curto: dramas
- URL: https://seu-site.github.io
```

### 2. Acessar o Mini App

Os usuários podem acessar via:
- Link direto: `https://t.me/SeuBot/dramas`
- Botão inline no chat do bot
- Menu do bot

---

## 💡 Exemplo de Bot de Vendas Python

```python
from telebot import TeleBot
import os

bot = TeleBot("SEU_TOKEN")

# Mapeamento de dramas para grupos
DRAMAS = {
    "drama1": {
        "nome": "Casamento Blindado",
        "preco": 19.90,
        "grupo": "https://t.me/+LINK_PRIVADO_GRUPO1"
    },
    "drama2": {
        "nome": "Um Contrato de Natal",
        "preco": 19.90,
        "grupo": "https://t.me/+LINK_PRIVADO_GRUPO2"
    }
}

@bot.message_handler(commands=['start'])
def start(message):
    args = message.text.split()
    
    if len(args) > 1:
        drama_id = args[1]
        drama = DRAMAS.get(drama_id)
        
        if drama:
            bot.send_message(
                message.chat.id,
                f"🎬 {drama['nome']}\n\n"
                f"💰 Preço: R$ {drama['preco']}\n\n"
                f"Clique em 'Pagar' para assistir!",
                reply_markup=criar_botao_pagamento(drama_id)
            )
    else:
        bot.send_message(message.chat.id, "Bem-vindo! Escolha um drama no catálogo.")

# Após pagamento confirmado:
def enviar_acesso(chat_id, drama_id):
    drama = DRAMAS[drama_id]
    bot.send_message(
        chat_id,
        f"✅ Pagamento confirmado!\n\n"
        f"🎉 Acesse o grupo para assistir:\n{drama['grupo']}"
    )

bot.polling()
```

---

## 📊 Estatísticas e Melhorias Futuras

### Possíveis Melhorias:
- ✅ Adicionar sistema de favoritos
- ✅ Mostrar "Mais Assistidos"
- ✅ Adicionar trailers dos dramas
- ✅ Sistema de avaliações dos usuários
- ✅ Notificações de novos dramas
- ✅ Cupons de desconto

---

## 🆘 Suporte e Dúvidas

### Problemas Comuns:

**1. Botão "Assistir Agora" não funciona**
- Verifique se o `botLink` está correto
- Teste o link manualmente no navegador

**2. Imagens não aparecem**
- Verifique se as URLs das imagens são públicas
- Use serviços como Imgur ou hospede no GitHub

**3. Busca não funciona**
- Limpe o cache do navegador
- Verifique se há erros no console (F12)

---

## 📝 Checklist de Lançamento

Antes de lançar seu site, verifique:

- [ ] Todos os dramas têm imagens de capa
- [ ] Links do bot estão corretos e únicos
- [ ] Bot de vendas está funcionando
- [ ] Grupos/canais privados estão criados
- [ ] Site está publicado e acessível
- [ ] Mini App está configurado no @BotFather
- [ ] Testou o fluxo completo (catálogo → bot → pagamento → acesso)

---

## 🎉 Pronto!

Seu site de streaming de dramas está pronto para uso! Personalize, publique e comece a vender! 🚀

**Boa sorte com seu negócio!** 💰✨
