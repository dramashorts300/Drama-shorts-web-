import { useState, useEffect, useRef } from "react";
import { Search, Play, MessageCircle, TrendingUp, Plus, Clock, Star, Package, Crown } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { dramas } from "@/data/dramas";

const CONTACT_LINK = "https://t.me/m/QIZf9-1zMTcx";
const COMBOS_LINK = "https://t.me/m/PAAURwcGMWMx";
const VIP_LINK = "https://t.me/m/LlxufKUqNGQx";

export default function Home() {
  const [searchTerm, setSearchTerm] = useState("");
  const [dramaClicks, setDramaClicks] = useState<Record<number, number>>({});
  const [siteVisits, setSiteVisits] = useState(0);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Carregar dados salvos
  useEffect(() => {
    const savedClicks = localStorage.getItem("dramaClicks");
    const savedVisits = localStorage.getItem("siteVisits");
    
    if (savedClicks) {
      setDramaClicks(JSON.parse(savedClicks));
    }
    
    if (savedVisits) {
      setSiteVisits(parseInt(savedVisits));
    } else {
      localStorage.setItem("siteVisits", "1");
      setSiteVisits(1);
    }
  }, []);

  // Incrementar visitas
  useEffect(() => {
    const currentVisits = parseInt(localStorage.getItem("siteVisits") || "0");
    const newVisits = currentVisits + 1;
    localStorage.setItem("siteVisits", newVisits.toString());
    setSiteVisits(newVisits);
  }, []);

  const handleDramaClick = (dramaId: number) => {
    const newClicks = {
      ...dramaClicks,
      [dramaId]: (dramaClicks[dramaId] || 0) + 1
    };
    setDramaClicks(newClicks);
    localStorage.setItem("dramaClicks", JSON.stringify(newClicks));
  };

  // Carregar dramas salvos do localStorage
  const [localDramas, setLocalDramas] = useState(dramas);
  
  useEffect(() => {
    const loadDramas = () => {
      const saved = localStorage.getItem("drama-shorts-admin-data");
      if (saved) {
        try {
          setLocalDramas(JSON.parse(saved));
        } catch (e) {
          console.error("Erro ao carregar dramas:", e);
        }
      }
    };

    loadDramas();

    // Listener para atualizar quando admin salvar
    window.addEventListener('storage', loadDramas);
    
    // Verificar a cada 2 segundos se houve atualização
    const interval = setInterval(loadDramas, 2000);

    return () => {
      window.removeEventListener('storage', loadDramas);
      clearInterval(interval);
    };
  }, []);

  const filteredDramas = searchTerm 
    ? localDramas.filter(drama =>
        drama.title.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  // Top 10 mais clicados
  const top10Dramas = [...localDramas]
    .sort((a, b) => (dramaClicks[b.id] || 0) - (dramaClicks[a.id] || 0))
    .slice(0, 10);

  // Mais populares da semana (baseado em rating)
  const popularDramas = [...localDramas]
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 25);

  // Recém adicionadas (últimos 25)
  const recentDramas = [...localDramas]
    .sort((a, b) => b.id - a.id)
    .slice(0, 25);

  // Todas as séries (primeiros 25)
  const allDramas = localDramas.slice(0, 25);

  const focusSearch = () => {
    searchInputRef.current?.focus();
    searchInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  const DramaCard = ({ drama, showRank }: { drama: any; showRank?: number }) => (
    <div className="group relative flex-shrink-0 w-32 sm:w-40">
      <div className="aspect-[2/3] rounded-md overflow-hidden bg-zinc-900 hover:ring-2 hover:ring-primary transition-all hover:scale-105">
        {showRank && (
          <div className="absolute top-1 left-1 z-10 w-7 h-7 rounded-full bg-gradient-to-br from-primary to-pink-600 flex items-center justify-center text-white font-bold text-xs shadow-lg">
            #{showRank}
          </div>
        )}

        <img 
          src={drama.thumbnail} 
          alt={drama.title}
          className="w-full h-full object-cover"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://via.placeholder.com/300x450/1a1a1a/fff?text=' + encodeURIComponent(drama.title);
          }}
        />

        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent">
          <div className="absolute bottom-0 left-0 right-0 p-2 space-y-1">
            <h3 className="font-bold text-white text-[10px] leading-tight line-clamp-2">{drama.title}</h3>
            <div className="flex items-center justify-between text-[9px]">
              <Badge variant="secondary" className="text-[8px] h-4 px-1">{drama.category}</Badge>
              <span className="text-yellow-500 flex items-center gap-0.5">
                ⭐ {drama.rating}
              </span>
            </div>
            
            <div className="space-y-1">
              {drama.showWatchButton && drama.watchCompleteLink && (
                <Button 
                  size="sm" 
                  className="w-full h-6 text-[9px] px-1 gap-0.5"
                  onClick={(e) => {
                    e.preventDefault();
                    handleDramaClick(drama.id);
                    toast.info("Clique em START e procure o título desejado", {
                      duration: 3000,
                    });
                    setTimeout(() => {
                      window.open(drama.watchCompleteLink, '_blank');
                    }, 1000);
                  }}
                >
                  <Play className="w-2.5 h-2.5" />
                  <span className="truncate">ASSISTIR AUTO.</span>
                </Button>
              )}
              
              {drama.showContactButton && (
                <a 
                  href={CONTACT_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => handleDramaClick(drama.id)}
                  className="block"
                >
                  <Button size="sm" variant="outline" className="w-full h-6 text-[9px] px-1 gap-0.5 border-white/20">
                    <MessageCircle className="w-2.5 h-2.5" />
                    <span className="truncate">FALAR ATEND.</span>
                  </Button>
                </a>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const HorizontalSection = ({ 
    title, 
    icon: Icon, 
    dramas: sectionDramas, 
    showRanking = false 
  }: { 
    title: string; 
    icon: any; 
    dramas: any[]; 
    showRanking?: boolean;
  }) => (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-3 px-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-pink-600 flex items-center justify-center">
            <Icon className="w-4 h-4" />
          </div>
          <h2 className="text-lg font-bold bg-gradient-to-r from-primary to-pink-500 bg-clip-text text-transparent">
            {title}
          </h2>
        </div>
        {sectionDramas.length >= 25 && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={focusSearch}
            className="gap-1 text-xs"
          >
            <Plus className="w-4 h-4" />
            Mais
          </Button>
        )}
      </div>

      <div className="overflow-x-auto scrollbar-hide">
        <div className="flex gap-3 px-3 pb-2">
          {sectionDramas.map((drama, index) => (
            <DramaCard 
              key={drama.id} 
              drama={drama} 
              showRank={showRanking ? index + 1 : undefined}
            />
          ))}
        </div>
      </div>
    </section>
  );

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-black/95 backdrop-blur-sm border-b border-zinc-800">
        <div className="container mx-auto px-3 py-3">
          <div className="flex items-center gap-2 mb-3">
            <img src="/logo.jpg" alt="Drama Shorts" className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <h1 className="text-base font-bold bg-gradient-to-r from-primary via-pink-500 to-yellow-500 bg-clip-text text-transparent truncate">
                DRAMA SHORTS
              </h1>
              <p className="text-[10px] text-zinc-400 truncate">Uma nova história a cada minuto!</p>
            </div>
            
            {/* Botão COMBOS */}
            <a href={COMBOS_LINK} target="_blank" rel="noopener noreferrer">
              <Button 
                size="sm" 
                className="h-7 px-3 rounded-full bg-blue-600 hover:bg-blue-700 text-[10px] font-bold gap-1 flex-shrink-0"
              >
                <Package className="w-3 h-3" />
                COMBOS
              </Button>
            </a>

            {/* Botão VIP */}
            <a href={VIP_LINK} target="_blank" rel="noopener noreferrer">
              <Button 
                size="sm" 
                className="h-7 px-2 rounded-full bg-yellow-500 hover:bg-yellow-600 text-black text-[9px] font-bold gap-1 flex-shrink-0"
              >
                <Crown className="w-3 h-3" />
                <span className="hidden sm:inline">JÁ CONHECE O </span>VIP?
              </Button>
            </a>
            
            <a href="/admin">
              <Button variant="ghost" size="sm" className="gap-1 flex-shrink-0 h-7 w-7 p-0">
                <span className="text-xs">⚙️</span>
              </Button>
            </a>
          </div>

          {/* Barra de Pesquisa */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-zinc-400 w-4 h-4" />
            <Input
              ref={searchInputRef}
              type="text"
              placeholder="Buscar dramas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-zinc-900 border-zinc-800 h-9 text-sm"
            />
          </div>
        </div>
      </header>

      <main className="py-4">
        {/* Resultados da Busca */}
        {searchTerm && (
          <section className="mb-8">
            <div className="px-3 mb-3">
              <h2 className="text-lg font-bold">
                Resultados para "{searchTerm}"
              </h2>
              <p className="text-xs text-zinc-400">{filteredDramas.length} resultados encontrados</p>
            </div>
            
            {filteredDramas.length > 0 ? (
              <div className="overflow-x-auto scrollbar-hide">
                <div className="flex gap-3 px-3 pb-2">
                  {filteredDramas.map((drama) => (
                    <DramaCard key={drama.id} drama={drama} />
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-8 px-3">
                <p className="text-zinc-400">Nenhum drama encontrado.</p>
              </div>
            )}
          </section>
        )}

        {/* Seções Horizontais */}
        {!searchTerm && (
          <>
            <HorizontalSection 
              title="Top 10 Mais Pedidas" 
              icon={TrendingUp} 
              dramas={top10Dramas}
              showRanking={true}
            />

            <HorizontalSection 
              title="Mais Populares da Semana" 
              icon={Star} 
              dramas={popularDramas}
            />

            <HorizontalSection 
              title="Recém Adicionadas" 
              icon={Clock} 
              dramas={recentDramas}
            />

            <HorizontalSection 
              title="Todas as Séries" 
              icon={Play} 
              dramas={allDramas}
            />
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 mt-12 py-6">
        <div className="container mx-auto px-3 text-center text-xs text-zinc-500">
          © 2024 Drama Shorts. Todos os direitos reservados.
        </div>
      </footer>

      <style dangerouslySetInnerHTML={{__html: `
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}} />
    </div>
  );
}
