import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { useState, useEffect } from "react";
import { Plus, Save, ArrowLeft, Trash2, Download, CheckCircle, Eye, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";

interface DramaForm {
  id: number;
  title: string;
  description: string;
  thumbnail: string;
  category: string;
  year: number;
  rating: number;
  watchCompleteLink: string;
  showWatchButton: boolean;
  showContactButton: boolean;
  clicks: number;
}

const STORAGE_KEY = "drama-shorts-admin-data";

export default function Admin() {
  const [dramas, setDramas] = useState<DramaForm[]>([]);
  const [hasChanges, setHasChanges] = useState(false);
  const [visits, setVisits] = useState(0);

  // Carregar dados salvos ao iniciar
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setDramas(parsed);
        toast.success("Dramas carregados com sucesso!");
      } catch (e) {
        toast.error("Erro ao carregar dramas salvos");
      }
    } else {
      // Iniciar com um drama vazio
      setDramas([{
        id: 1,
        title: "",
        description: "",
        thumbnail: "",
        category: "Romance",
        year: 2024,
        rating: 4.5,
        watchCompleteLink: "",
        showWatchButton: true,
        showContactButton: true,
        clicks: 0
      }]);
    }

    // Carregar contador de visitas
    const visitCount = parseInt(localStorage.getItem("drama-shorts-visits") || "0");
    setVisits(visitCount);
  }, []);

  const addDrama = () => {
    const newId = dramas.length > 0 ? Math.max(...dramas.map(d => d.id)) + 1 : 1;
    setDramas([...dramas, {
      id: newId,
      title: "",
      description: "",
      thumbnail: "",
      category: "Romance",
      year: 2024,
      rating: 4.5,
      watchCompleteLink: "",
      showWatchButton: true,
      showContactButton: true,
      clicks: 0
    }]);
    setHasChanges(true);
  };

  const updateDrama = (id: number, field: keyof DramaForm, value: any) => {
    setDramas(dramas.map(drama => 
      drama.id === id ? { ...drama, [field]: value } : drama
    ));
    setHasChanges(true);
  };

  const removeDrama = (id: number) => {
    if (dramas.length === 1) {
      toast.error("Você precisa ter pelo menos 1 drama!");
      return;
    }
    setDramas(dramas.filter(drama => drama.id !== id));
    setHasChanges(true);
    toast.success("Drama removido!");
  };

  const saveDramas = () => {
    // Validar apenas campos obrigatórios (título e capa)
    const invalid = dramas.find(d => !d.title || !d.thumbnail);
    if (invalid) {
      toast.error("Preencha os campos obrigatórios: Título e Link da Capa!");
      return;
    }

    // Salvar no localStorage
    localStorage.setItem(STORAGE_KEY, JSON.stringify(dramas));
    setHasChanges(false);
    toast.success("✅ Dramas salvos com sucesso!");
  };

  const finishEditing = () => {
    saveDramas();
    toast.success("🎉 Edição finalizada! Seus dramas estão no ar!");
    // Recarregar a página para atualizar o catálogo
    setTimeout(() => {
      window.location.href = "/";
    }, 1500);
  };

  const exportData = () => {
    const dataStr = JSON.stringify(dramas, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'dramas-backup.json';
    link.click();
    toast.success("Backup exportado!");
  };

  // Top dramas por cliques
  const topDramas = [...dramas].sort((a, b) => b.clicks - a.clicks).slice(0, 5);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-10 shadow-lg">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Painel Admin
              </h1>
              <p className="text-sm text-muted-foreground">
                {dramas.length} drama{dramas.length !== 1 ? 's' : ''} cadastrado{dramas.length !== 1 ? 's' : ''}
                {hasChanges && <span className="text-yellow-500 ml-2">● Não salvo</span>}
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={() => {
                const newDramaForm = document.getElementById('new-drama-form');
                newDramaForm?.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }}
              variant="default"
              size="sm"
              className="gap-2 bg-gradient-to-r from-primary to-pink-600"
            >
              <Plus className="w-4 h-4" />
              Nova Série/Filme
            </Button>
            <Button onClick={exportData} variant="outline" size="sm" className="gap-2 hidden md:flex">
              <Download className="w-4 h-4" />
              Backup
            </Button>
            <Button 
              onClick={saveDramas} 
              variant="outline"
              size="sm"
              className="gap-2"
              disabled={!hasChanges}
            >
              <Save className="w-4 h-4" />
              Salvar
            </Button>
            <Button 
              onClick={finishEditing} 
              className="gap-2"
              disabled={!dramas.some(d => d.title && d.thumbnail)}
            >
              <CheckCircle className="w-4 h-4" />
              Finalizar
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <Card className="bg-gradient-to-br from-primary/10 to-secondary/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Visitas Totais
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-primary">{visits.toLocaleString()}</p>
              <p className="text-sm text-muted-foreground mt-1">Acessos ao site</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Top 5 Mais Clicados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {topDramas.slice(0, 3).map((drama, index) => (
                  <div key={drama.id} className="flex items-center justify-between text-sm">
                    <span className="truncate flex-1">
                      {index + 1}. {drama.title || `Drama #${drama.id}`}
                    </span>
                    <span className="text-muted-foreground ml-2">{drama.clicks} 👁️</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6 bg-gradient-to-r from-primary/10 to-secondary/10">
          <CardHeader>
            <CardTitle>✨ Como Usar</CardTitle>
            <CardDescription className="space-y-2">
              <p><strong>1.</strong> Preencha o <strong>Título</strong> e o <strong>Link da Capa</strong> (obrigatórios)</p>
              <p><strong>2.</strong> Cole o link do bot em <strong>"Link Assistir Completo"</strong></p>
              <p><strong>3.</strong> Escolha quais botões mostrar (Assistir Completo e/ou Falar com Atendente)</p>
              <p><strong>4.</strong> Clique em <strong>"Finalizar"</strong> quando terminar</p>
            </CardDescription>
          </CardHeader>
        </Card>

        <div className="space-y-6" id="new-drama-form">
          {dramas.map((drama, index) => (
            <Card key={drama.id} className="relative">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    Drama #{drama.id}
                    {drama.clicks > 0 && <span className="text-xs text-muted-foreground">({drama.clicks} cliques)</span>}
                    {!drama.title && <span className="text-xs text-muted-foreground">(Novo)</span>}
                    {drama.title && <span className="text-sm font-normal text-muted-foreground">- {drama.title}</span>}
                  </CardTitle>
                  {dramas.length > 1 && (
                    <Button 
                      variant="destructive" 
                      size="sm"
                      onClick={() => removeDrama(drama.id)}
                      className="gap-2"
                    >
                      <Trash2 className="w-4 h-4" />
                      Remover
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor={`title-${drama.id}`}>
                      Título * {!drama.title && <span className="text-destructive text-xs">(obrigatório)</span>}
                    </Label>
                    <Input
                      id={`title-${drama.id}`}
                      placeholder="Ex: Casamento Blindado"
                      value={drama.title}
                      onChange={(e) => updateDrama(drama.id, 'title', e.target.value)}
                      className={!drama.title ? "border-destructive" : ""}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`category-${drama.id}`}>Categoria</Label>
                    <Select
                      value={drama.category}
                      onValueChange={(value) => updateDrama(drama.id, 'category', value)}
                    >
                      <SelectTrigger id={`category-${drama.id}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Romance">Romance</SelectItem>
                        <SelectItem value="Ação">Ação</SelectItem>
                        <SelectItem value="Comédia">Comédia</SelectItem>
                        <SelectItem value="Drama">Drama</SelectItem>
                        <SelectItem value="Suspense">Suspense</SelectItem>
                        <SelectItem value="Aventura">Aventura</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`description-${drama.id}`}>
                    Descrição <span className="text-xs text-muted-foreground">(opcional)</span>
                  </Label>
                  <Textarea
                    id={`description-${drama.id}`}
                    placeholder="Descreva o drama... (opcional)"
                    value={drama.description}
                    onChange={(e) => updateDrama(drama.id, 'description', e.target.value)}
                    rows={2}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`thumbnail-${drama.id}`}>
                    Link da Capa (Imgur) * {!drama.thumbnail && <span className="text-destructive text-xs">(obrigatório)</span>}
                  </Label>
                  <Input
                    id={`thumbnail-${drama.id}`}
                    placeholder="https://i.imgur.com/ABC123.jpg"
                    value={drama.thumbnail}
                    onChange={(e) => updateDrama(drama.id, 'thumbnail', e.target.value)}
                    className={!drama.thumbnail ? "border-destructive" : ""}
                  />
                  {drama.thumbnail && (
                    <div className="mt-2">
                      <p className="text-xs font-medium mb-2">Preview:</p>
                      <img 
                        src={drama.thumbnail} 
                        alt="Preview" 
                        className="w-32 h-48 object-cover rounded-lg border-2 border-primary/20"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://via.placeholder.com/300x450/333/fff?text=Link+Invalido';
                        }}
                      />
                    </div>
                  )}
                </div>

                {/* Novos campos de botões */}
                <div className="space-y-4 p-4 border border-primary/20 rounded-lg bg-primary/5">
                  <h4 className="font-semibold text-sm">Configuração dos Botões</h4>
                  
                  <div className="space-y-2">
                    <Label htmlFor={`watchLink-${drama.id}`}>
                      Link "Assistir Completo Instantaneamente"
                    </Label>
                    <Input
                      id={`watchLink-${drama.id}`}
                      placeholder="https://t.me/seu_bot..."
                      value={drama.watchCompleteLink}
                      onChange={(e) => updateDrama(drama.id, 'watchCompleteLink', e.target.value)}
                    />
                    <div className="flex items-center space-x-2 mt-2">
                      <Checkbox
                        id={`showWatch-${drama.id}`}
                        checked={drama.showWatchButton}
                        onCheckedChange={(checked) => updateDrama(drama.id, 'showWatchButton', checked)}
                      />
                      <Label htmlFor={`showWatch-${drama.id}`} className="cursor-pointer text-sm">
                        Mostrar botão "ASSISTIR COMPLETO INSTANTANEAMENTE"
                      </Label>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id={`showContact-${drama.id}`}
                      checked={drama.showContactButton}
                      onCheckedChange={(checked) => updateDrama(drama.id, 'showContactButton', checked)}
                    />
                    <Label htmlFor={`showContact-${drama.id}`} className="cursor-pointer text-sm">
                      Mostrar botão "FALAR COM ATENDENTE"
                    </Label>
                  </div>

                  <p className="text-xs text-muted-foreground">
                    ℹ️ Você pode mostrar ambos os botões, apenas um, ou nenhum
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor={`year-${drama.id}`}>Ano</Label>
                    <Input
                      id={`year-${drama.id}`}
                      type="number"
                      value={drama.year}
                      onChange={(e) => updateDrama(drama.id, 'year', parseInt(e.target.value) || 2024)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`rating-${drama.id}`}>Avaliação (0-5)</Label>
                    <Input
                      id={`rating-${drama.id}`}
                      type="number"
                      step="0.1"
                      min="0"
                      max="5"
                      value={drama.rating}
                      onChange={(e) => updateDrama(drama.id, 'rating', parseFloat(e.target.value) || 4.5)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Button onClick={addDrama} className="w-full mt-6 gap-2" variant="outline" size="lg">
          <Plus className="w-5 h-5" />
          Adicionar Novo Drama
        </Button>

        {hasChanges && (
          <Card className="mt-6 bg-yellow-500/10 border-yellow-500/50">
            <CardContent className="pt-6">
              <p className="text-center font-medium">
                ⚠️ Você tem alterações não salvas! Clique em "Salvar" ou "Finalizar".
              </p>
            </CardContent>
          </Card>
        )}

        {/* Botão Finalizar Grande */}
        <Card className="mt-6 bg-gradient-to-r from-primary/20 to-secondary/20 border-primary/50">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <h3 className="text-xl font-bold">Pronto para publicar?</h3>
              <p className="text-muted-foreground">
                Clique em "Finalizar" para salvar e ver seus dramas no site!
              </p>
              <Button 
                onClick={finishEditing} 
                size="lg"
                className="gap-2 text-lg px-8"
                disabled={!dramas.some(d => d.title && d.thumbnail)}
              >
                <CheckCircle className="w-5 h-5" />
                Finalizar e Publicar
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
