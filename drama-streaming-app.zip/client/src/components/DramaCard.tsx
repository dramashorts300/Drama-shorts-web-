import { Drama } from "@/data/dramas";
import { Card } from "@/components/ui/card";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DramaCardProps {
  drama: Drama;
}

export default function DramaCard({ drama }: DramaCardProps) {
  const handleClick = () => {
    // Abre o bot de vendas no Telegram com o ID do drama
    window.open(drama.botLink, '_blank');
  };

  return (
    <Card className="overflow-hidden transition-all hover:scale-105 hover:shadow-xl hover:shadow-primary/30 border-primary/10">
      <div className="relative aspect-[3/4] overflow-hidden group">
        <img
          src={drama.thumbnail}
          alt={drama.title}
          className="w-full h-full object-cover transition-transform group-hover:scale-110"
        />
        {/* Overlay com gradiente */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />
        
        {/* Rating badge com efeito neon */}
        <div className="absolute top-2 right-2 bg-black/80 backdrop-blur-sm px-2 py-1 rounded-full flex items-center gap-1 border border-secondary/50 shadow-lg shadow-secondary/20">
          <Star className="w-4 h-4 fill-secondary text-secondary" />
          <span className="text-white text-sm font-semibold">{drama.rating}</span>
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg line-clamp-1 mb-1">{drama.title}</h3>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
          {drama.description}
        </p>
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
          <span className="bg-primary/10 text-primary px-2 py-1 rounded">
            {drama.category}
          </span>
          <span>{drama.year}</span>
        </div>
        <Button 
          onClick={handleClick}
          className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg shadow-primary/20"
          size="sm"
        >
          Assistir Agora
        </Button>
      </div>
    </Card>
  );
}
