/**
 * 🎬 ARQUIVO DE CAPAS - Gerado automaticamente
 * 
 * NÃO EDITE ESTE ARQUIVO DIRETAMENTE!
 * Edite o arquivo EDITAR_CAPAS_AQUI.txt na raiz do projeto
 * e execute: pnpm update-capas
 */

export const capas = {
  drama1: "https://placehold.co/300x450/1a1a1a/e91e63?text=Casamento+Blindado&font=roboto",
  drama2: "https://placehold.co/300x450/1a1a1a/4ECDC4?text=Contrato+de+Natal&font=roboto",
  drama3: "https://placehold.co/300x450/1a1a1a/FFE66D?text=Amor+Verdadeiro&font=roboto",
  drama4: "https://placehold.co/300x450/1a1a1a/A8E6CF?text=Vinganca+e+Poder&font=roboto",
  drama5: "https://placehold.co/300x450/1a1a1a/FF6B9D?text=Comedia+da+Vida&font=roboto",
  drama6: "https://placehold.co/300x450/1a1a1a/C7CEEA?text=Misterio+na+Cidade&font=roboto",
  drama7: "https://placehold.co/300x450/1a1a1a/FFEAA7?text=Familia+Unida&font=roboto",
  drama8: "https://placehold.co/300x450/1a1a1a/DFE6E9?text=Aventura+no+Sertao&font=roboto",
  drama9: "https://placehold.co/300x450/1a1a1a/FAB1A0?text=Paixao+Proibida&font=roboto",
  drama10: "https://placehold.co/300x450/1a1a1a/74B9FF?text=Herois+do+Cotidiano&font=roboto",
  drama11: "https://placehold.co/300x450/1a1a1a/e91e63?text=Novo+Drama&font=roboto",
  drama12: "https://placehold.co/300x450/1a1a1a/e91e63?text=Novo+Drama&font=roboto",
  drama13: "https://placehold.co/300x450/1a1a1a/e91e63?text=Novo+Drama&font=roboto",
};
