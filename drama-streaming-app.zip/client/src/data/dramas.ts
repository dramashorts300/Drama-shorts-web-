import { capas } from './capas';

export interface Drama {
  id: number;
  title: string;
  description: string;
  thumbnail: string;
  category: string;
  year: number;
  rating: number;
  // Novos campos para botões
  watchCompleteLink?: string; // Link para assistir completo
  showWatchButton?: boolean;   // Mostrar botão "Assistir Completo"?
  showContactButton?: boolean; // Mostrar botão "Falar com Atendente"?
  // Sistema de cliques
  clicks?: number; // Contador de cliques
  // Deprecated (manter para compatibilidade)
  botLink?: string;
  popular?: boolean;
}

// Dados de exemplo - substitua pelos seus próprios dramas e links do Telegram
export const dramas: Drama[] = [
  {
    id: 1,
    title: "Casamento Blindado",
    description: "Um casal enfrenta desafios para manter seu casamento forte e feliz.",
    thumbnail: capas.drama1,
    category: "Romance",
    year: 2024,
    rating: 4.8,
    watchCompleteLink: "",
    showWatchButton: true,
    showContactButton: true,
    clicks: 0,
    popular: true
  },
  {
    id: 2,
    title: "Um Contrato de Natal",
    description: "Uma história mágica sobre amor e segundas chances durante o Natal.",
    thumbnail: capas.drama2,
    category: "Romance",
    year: 2024,
    rating: 4.5,
    watchCompleteLink: "",
    showWatchButton: true,
    showContactButton: true,
    clicks: 0
  },
  {
    id: 3,
    title: "Amor Verdadeiro",
    description: "Dois corações se encontram em meio ao caos da vida moderna.",
    thumbnail: capas.drama3,
    category: "Romance",
    year: 2023,
    rating: 4.7,
    watchCompleteLink: "",
    showWatchButton: true,
    showContactButton: true,
    clicks: 0,
    popular: true
  },
  {
    id: 4,
    title: "Vingança e Poder",
    description: "Uma trama cheia de reviravoltas sobre vingança e redenção.",
    thumbnail: capas.drama4,
    category: "Ação",
    year: 2024,
    rating: 4.6,
    watchCompleteLink: "",
    showWatchButton: true,
    showContactButton: true,
    clicks: 0
  },
  {
    id: 5,
    title: "Comédia da Vida",
    description: "Situações hilariantes do dia a dia de uma família brasileira.",
    thumbnail: capas.drama5,
    category: "Comédia",
    year: 2024,
    rating: 4.9,
    watchCompleteLink: "",
    showWatchButton: true,
    showContactButton: true,
    clicks: 0,
    popular: true
  },
  {
    id: 6,
    title: "Mistério na Cidade",
    description: "Um detetive investiga crimes misteriosos em uma grande metrópole.",
    thumbnail: capas.drama6,
    category: "Suspense",
    year: 2023,
    rating: 4.4,
    watchCompleteLink: "",
    showWatchButton: true,
    showContactButton: true,
    clicks: 0
  },
  {
    id: 7,
    title: "Família Unida",
    description: "A jornada de uma família que supera obstáculos juntos.",
    thumbnail: capas.drama7,
    category: "Drama",
    year: 2024,
    rating: 4.8,
    watchCompleteLink: "",
    showWatchButton: true,
    showContactButton: true,
    clicks: 0,
    popular: true
  },
  {
    id: 8,
    title: "Aventura no Sertão",
    description: "Uma aventura emocionante pelo interior do Brasil.",
    thumbnail: capas.drama8,
    category: "Aventura",
    year: 2023,
    rating: 4.3,
    watchCompleteLink: "",
    showWatchButton: true,
    showContactButton: true,
    clicks: 0
  },
  {
    id: 9,
    title: "Paixão Proibida",
    description: "Um amor impossível que desafia todas as convenções.",
    thumbnail: capas.drama9,
    category: "Romance",
    year: 2024,
    rating: 4.7,
    watchCompleteLink: "",
    showWatchButton: true,
    showContactButton: true,
    clicks: 0
  },
  {
    id: 10,
    title: "Heróis do Cotidiano",
    description: "Histórias inspiradoras de pessoas comuns que fazem a diferença.",
    thumbnail: capas.drama10,
    category: "Drama",
    year: 2024,
    rating: 4.9,
    watchCompleteLink: "",
    showWatchButton: true,
    showContactButton: true,
    clicks: 0
  }
];

export const categories = [
  "Todos",
  "Romance",
  "Ação",
  "Comédia",
  "Drama",
  "Suspense",
  "Aventura"
];
