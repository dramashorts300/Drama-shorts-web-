# 📝 Como Editar Seu Site Drama Shorts

## 🎨 1. Como Adicionar/Trocar Capas dos Dramas

### Opção A: Usar URLs de Imagens Online (Mais Fácil)

1. **Faça upload das suas imagens** para um serviço gratuito:
   - [Imgur](https://imgur.com) - Recomendado
   - [ImgBB](https://imgbb.com)
   - Google Drive (tornar público)

2. **Copie o link direto da imagem**

3. **Edite o arquivo** `/client/src/data/dramas.ts`:

```typescript
{
  id: 1,
  title: "Nome do Seu Drama",
  description: "Descrição do drama",
  thumbnail: "https://i.imgur.com/SUA_IMAGEM.jpg", // ← Cole o link aqui
  category: "Romance",
  year: 2024,
  rating: 4.8,
  botLink: "https://t.me/m/QIZf9-1zMTcx"
}
```

### Opção B: Usar Imagens Locais (Hospedadas no Projeto)

1. **Coloque suas imagens** na pasta `/client/public/capas/`
   - Crie a pasta `capas` se não existir
   - Nomeie as imagens: `drama1.jpg`, `drama2.jpg`, etc.

2. **Edite o arquivo** `/client/src/data/dramas.ts`:

```typescript
{
  id: 1,
  title: "Nome do Seu Drama",
  thumbnail: "/capas/drama1.jpg", // ← Caminho relativo
  // ... resto do código
}
```

**Dica:** Use imagens com proporção **3:4** (vertical) para melhor resultado. Tamanho recomendado: 300x400px ou 600x800px.

---

## 📺 2. Como Adicionar Novos Dramas

Edite o arquivo `/client/src/data/dramas.ts` e adicione um novo objeto no array:

```typescript
export const dramas: Drama[] = [
  // Dramas existentes...
  
  {
    id: 11, // ← Próximo ID sequencial
    title: "Novo Drama Incrível",
    description: "Uma história emocionante sobre...",
    thumbnail: "https://i.imgur.com/SUA_IMAGEM.jpg",
    category: "Romance", // Romance, Ação, Comédia, Drama, Suspense, Aventura
    year: 2024,
    rating: 4.7, // De 0.0 a 5.0
    botLink: "https://t.me/m/QIZf9-1zMTcx"
  }
];
```

---

## 🗑️ 3. Como Remover Dramas

No arquivo `/client/src/data/dramas.ts`, simplesmente **delete o objeto completo** do drama que você quer remover:

```typescript
// Remova tudo entre as chaves { } incluindo as chaves
{
  id: 3,
  title: "Amor Verdadeiro",
  // ... todo o conteúdo
}, // ← Remova a vírgula também se for o último item
```

---

## ✏️ 4. Como Editar Informações dos Dramas

Abra `/client/src/data/dramas.ts` e modifique os campos:

```typescript
{
  id: 1,
  title: "Novo Título", // ← Mude o título
  description: "Nova descrição mais atrativa...", // ← Mude a descrição
  thumbnail: "novo_link.jpg", // ← Mude a capa
  category: "Ação", // ← Mude a categoria
  year: 2025, // ← Mude o ano
  rating: 5.0, // ← Mude a avaliação
  botLink: "https://t.me/m/QIZf9-1zMTcx" // ← Já está configurado!
}
```

---

## 🏷️ 5. Como Adicionar Novas Categorias

No arquivo `/client/src/data/dramas.ts`, edite o array de categorias:

```typescript
export const categories = [
  "Todos",
  "Romance",
  "Ação",
  "Comédia",
  "Drama",
  "Suspense",
  "Aventura",
  "Terror", // ← Adicione novas categorias aqui
  "Ficção Científica",
  "Histórico"
];
```

**Importante:** A categoria do drama deve corresponder exatamente ao nome na lista!

---

## 🎨 6. Como Mudar Cores do Site

Edite o arquivo `/client/src/index.css`:

```css
:root {
  --primary: oklch(0.55 0.25 350); /* Rosa/Vermelho - cor principal */
  --secondary: oklch(0.75 0.18 60); /* Dourado - cor secundária */
  --background: oklch(0.12 0.01 0); /* Preto - fundo */
  --foreground: oklch(0.98 0 0); /* Branco - texto */
}
```

**Dica:** Use ferramentas como [oklch.com](https://oklch.com) para escolher cores.

---

## 🔗 7. Como Mudar o Link do Botão "Assistir Agora"

### Para Mudar em TODOS os Dramas:

Edite `/client/src/data/dramas.ts` e use "Find & Replace" (Ctrl+H):

- **Buscar:** `https://t.me/m/QIZf9-1zMTcx`
- **Substituir por:** `SEU_NOVO_LINK`

### Para Mudar em UM Drama Específico:

```typescript
{
  id: 1,
  title: "Drama Especial",
  // ...
  botLink: "https://t.me/m/LINK_DIFERENTE" // ← Link único para este drama
}
```

---

## 🚀 8. Como Publicar as Alterações

### Se Estiver Usando GitHub Pages:

1. **Salve todas as alterações** nos arquivos
2. **Faça commit e push** para o GitHub:
   ```bash
   git add .
   git commit -m "Atualizar dramas e capas"
   git push origin main
   ```
3. **Aguarde 1-2 minutos** - GitHub Pages atualiza automaticamente!

### Se Estiver Usando Vercel/Netlify:

1. **Salve todas as alterações**
2. **Faça push para o GitHub**
3. **Deploy automático** acontece em segundos!

---

## 🤖 9. Como Integrar com Telegram Mini App

### Passo 1: Publicar o Site

Primeiro, publique seu site em um dos serviços:
- **GitHub Pages** (gratuito)
- **Vercel** (gratuito)
- **Netlify** (gratuito)

Você receberá uma URL como:
```
https://seu-usuario.github.io/drama-shorts/
```

### Passo 2: Criar o Mini App no @BotFather

1. Abra o Telegram e procure **@BotFather**

2. Se você ainda não tem um bot, crie um:
   ```
   /newbot
   ```
   - Nome: Drama Shorts
   - Username: DramaShortsBot (ou outro disponível)

3. Crie o Mini App:
   ```
   /newapp
   ```

4. **Selecione seu bot**

5. **Preencha as informações:**
   - **Título:** Drama Shorts
   - **Nome curto (short name):** dramas
   - **Descrição:** Envie `/empty` para pular
   - **Foto:** Envie sua logo ou `/empty`
   - **GIF de demo:** Envie `/empty`
   - **URL do Web App:** Cole a URL do seu site:
     ```
     https://seu-usuario.github.io/drama-shorts/
     ```

### Passo 3: Testar o Mini App

Acesse seu Mini App via:
```
https://t.me/SeuBotUsername/dramas
```

Ou abra o bot e clique no botão do Mini App!

### Passo 4: Compartilhar com Usuários

Compartilhe o link:
```
https://t.me/SeuBotUsername/dramas
```

---

## 📱 10. Estrutura de Arquivos Importantes

```
drama-streaming-app/
├── client/
│   ├── public/
│   │   ├── logo.jpg          ← Sua logo (já está aqui!)
│   │   └── capas/            ← Crie esta pasta para imagens locais
│   └── src/
│       ├── data/
│       │   └── dramas.ts     ← EDITE AQUI: dramas, categorias, links
│       ├── components/
│       │   └── DramaCard.tsx ← Componente do card
│       ├── pages/
│       │   └── Home.tsx      ← Página principal
│       └── index.css         ← EDITE AQUI: cores e estilos
```

---

## 🆘 11. Problemas Comuns

### "As alterações não aparecem no site"

**Solução:**
1. Limpe o cache do navegador (Ctrl + Shift + R)
2. Aguarde alguns minutos se estiver usando GitHub Pages
3. Verifique se fez commit e push das alterações

### "Imagens não aparecem"

**Solução:**
1. Verifique se o link da imagem está correto
2. Teste o link abrindo em uma nova aba do navegador
3. Certifique-se de que a imagem é pública (não privada)

### "Botão não abre o Telegram"

**Solução:**
1. Verifique se o link está correto em `/client/src/data/dramas.ts`
2. Teste o link manualmente copiando e colando no navegador
3. Certifique-se de que o link começa com `https://t.me/`

---

## 💡 12. Dicas Extras

### Otimizar Imagens

Use ferramentas para comprimir imagens antes de fazer upload:
- [TinyPNG](https://tinypng.com)
- [Squoosh](https://squoosh.app)

### Testar Localmente

Para testar suas alterações antes de publicar:

```bash
cd drama-streaming-app
pnpm install
pnpm dev
```

Abra `http://localhost:3000` no navegador.

### Backup

Sempre faça backup do arquivo `/client/src/data/dramas.ts` antes de fazer grandes alterações!

---

## 🎉 Pronto!

Agora você sabe editar tudo no seu site! Qualquer dúvida, consulte este guia. Boa sorte! 🚀✨
