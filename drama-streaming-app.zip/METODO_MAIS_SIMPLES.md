# 🎯 MÉTODO MAIS SIMPLES - Editar Capas Diretamente

## ✨ A Forma Mais Fácil de Todas!

Esqueça comandos e arquivos extras! Agora você edita **diretamente no arquivo principal**!

---

## 📝 Passo a Passo (3 Passos Apenas!)

### **Passo 1: Fazer Upload no Imgur**

1. Vá em [**https://imgur.com**](https://imgur.com)

1. Clique em **"New post"**

1. Faça upload da imagem

1. Clique com botão direito → **"Copiar endereço da imagem"**

1. Link copiado: `https://i.imgur.com/ABC123.jpg` ✅

---

### **Passo 2: Abrir o Arquivo de Dados**

No painel **Code** do Manus, navegue até:

```
client → src → data → dramas.ts
```

**Caminho completo:** `client/src/data/dramas.ts`

---

### **Passo 3: Colar o Link Diretamente**

Você verá algo assim:

```typescript
{
  id: 1,
  title: "Casamento Blindado",
  description: "Um casal enfrenta desafios...",
  thumbnail: "https://via.placeholder.com/300x400/...",  // ← AQ[https://imgur.com/a/KZDrFO6](https://imgur.com/a/KZDrFO6)UI!
  category: "Romance",
  year: 2024,
  rating: 4.8,
  botLink: "https://t.me/m/QIZf9-1zMTcx",
  popular: true
}
```

**Substitua a linha ****`thumbnail:`****:**

**ANTES:**

```typescript
thumbnail: "https://via.placeholder.com/300x400/...",
```

**DEPOIS:**

```typescript
thumbnail: "https://i.imgur.com/SUA_IMAGEM.jpg",
```

**Salve o arquivo (Ctrl + S)** e pronto! ✅

---

## 🎯 Exemplo Completo

### Você quer mudar a capa do drama "Casamento Blindado":

**1. Upload no Imgur:**

- Link obtido: `https://i.imgur.com/XYZ789.jpg`

**2. Abra ****`client/src/data/dramas.ts`**

**3. Encontre o drama:**

```typescript
{
  id: 1,
  title: "Casamento Blindado",
  description: "Um casal enfrenta desafios para manter seu casamento forte e feliz.",
  thumbnail: "https://via.placeholder.com/300x400/FF6B6B/FFFFFF?text=Casamento+Blindado",
  category: "Romance",
  year: 2024,
  rating: 4.8,
  botLink: "https://t.me/m/QIZf9-1zMTcx",
  popular: true
}
```

**4. Mude apenas a linha do ****`thumbnail`****:**

```typescript
{
  id: 1,
  title: "Casamento Blindado",
  description: "Um casal enfrenta desafios para manter seu casamento forte e feliz.",
  thumbnail: "https://i.imgur.com/XYZ789.jpg",  // ← MUDOU AQUI!
  category: "Romance",
  year: 2024,
  rating: 4.8,
  botLink: "https://t.me/m/QIZf9-1zMTcx",
  popular: true
}
```

**5. Salve (Ctrl + S)**

**6. Pronto! 🎉** A capa foi atualizada automaticamente!

---

## 🆕 Para Adicionar Novo Drama

Role até o final do arquivo `dramas.ts` e adicione:

```typescript
export const dramas: Drama[] = [
  // ... dramas existentes ...
  
  {
    id: 11,  // ← Próximo número
    title: "Nome do Novo Drama",
    description: "Descrição interessante do drama...",
    thumbnail: "https://i.imgur.com/NOVA_CAPA.jpg",  // ← Seu link aqui
    category: "Romance",  // Romance, Ação, Comédia, Drama, Suspense, Aventura
    year: 2024,
    rating: 4.5,
    botLink: "https://t.me/m/QIZf9-1zMTcx",
    popular: false  // true = aparece em "Mais Pedidas"
  }
];
```

---

## ⭐ Marcar como "Mais Pedido"

Para um drama aparecer na seção **"Mais Pedidas"**:

```typescript
{
  id: 1,
  title: "Drama Popular",
  // ... outros campos
  popular: true  // ← Mude para true!
}
```

---

## 📋 Checklist Rápido

- [ ] Fiz upload da imagem no Imgur

- [ ] Copiei o link da imagem

- [ ] Abri o arquivo `client/src/data/dramas.ts`

- [ ] Encontrei o drama que quero editar

- [ ] Colei o link na linha `thumbnail:`

- [ ] Salvei o arquivo (Ctrl + S)

- [ ] A capa foi atualizada! ✅

---

## 🔍 Como Encontrar o Arquivo?

### No Painel Code:

```
📁 drama-streaming-app/
  📁 client/
    📁 src/
      📁 data/
        📄 dramas.ts  ← AQUI!
```

**Ou use a busca:**

1. Pressione **Ctrl + P** (ou Cmd + P no Mac)

1. Digite: `dramas.ts`

1. Pressione Enter

---

## 💡 Dicas Importantes

### ✅ Sempre use aspas duplas:

```typescript
thumbnail: "link aqui",  // ← Correto
```

### ✅ Não esqueça a vírgula no final:

```typescript
thumbnail: "link aqui",  // ← Vírgula aqui!
```

### ✅ Mantenha o formato do link:

```typescript
thumbnail: "https://i.imgur.com/ABC123.jpg",  // ← Completo com https://
```

---

## 🆘 Problemas Comuns

### "Não encontro o arquivo dramas.ts"

**Solução:**

1. No painel Code, clique em **client**

1. Depois clique em **src**

1. Depois clique em **data**

1. Você verá **dramas.ts**

### "Deu erro ao salvar"

**Verifique:**

- Tem aspas duplas? `"link"`

- Tem vírgula no final? `"link",`

- O link está completo? `https://...`

### "A imagem não aparece"

**Teste o link:**

1. Copie o link

1. Abra uma nova aba do navegador

1. Cole o link e pressione Enter

1. A imagem deve aparecer

---

## 🎉 Resumo Ultra Rápido

```
1. Upload no Imgur → Copiar link
         ↓
2. Abrir dramas.ts → Colar no thumbnail
         ↓
3. Salvar (Ctrl + S) → Pronto! ✅
```

**SEM COMANDOS! SEM COMPLICAÇÃO!** 🚀

---

## 📞 Ainda com Dúvida?

Me avise e eu te ajudo passo a passo! 😊

